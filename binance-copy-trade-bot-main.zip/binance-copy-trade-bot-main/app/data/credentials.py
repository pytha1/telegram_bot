bot_token = ""
auth_code = ""  # set it yourself
admin_code = ""  # set it yourself
ip = ""
db_user = ""
db_pw = ""
