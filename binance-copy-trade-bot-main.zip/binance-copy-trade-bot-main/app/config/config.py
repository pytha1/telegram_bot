# WEB DRIVER CONFIG (Chrome)
chrome_location = ""
driver_location = ""
